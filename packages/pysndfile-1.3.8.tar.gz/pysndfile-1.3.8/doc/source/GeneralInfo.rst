Copyright
---------

Copyright (C) 2014-2018 IRCAM

Author
------

Axel Roebel

Credits
-------

-  Erik de Castro Lopo: for
   `libsndfile <http://www.mega-nerd.com/libsndfile/>`__
-  David Cournapeau: for a few ideas I gathered from
   `scikits.audiolab <http://cournape.github.io/audiolab/>`__.
-  The `Cython <http://cython.org>`__ maintainers for the efficient
   means to write interface definitions in Cython.

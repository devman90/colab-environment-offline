from osqp.interface import OSQP
from osqp._osqp import constant

Contributing
============
All development is done on GitHub: https://github.com/albu/albumentations

If you find a bug or have a feature request file an issue at https://github.com/albu/albumentations/issues
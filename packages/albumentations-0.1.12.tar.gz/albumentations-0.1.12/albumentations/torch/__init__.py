from albumentations.pytorch import *
import warnings
warnings.warn("`torch` module inside albumentations is deprecated and will be deleted in 0.3.0. "
              "please use `pytorch` module instead", DeprecationWarning)

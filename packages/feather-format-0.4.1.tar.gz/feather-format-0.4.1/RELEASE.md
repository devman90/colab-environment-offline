# Feather release notes

## 0.3.0 (August XX, 2016)

- ENH: Added `columns` option to `read_dataframe` to read only a subset of a
  file's columns
- BUG: Enabled Feather files over 2 GB on Windows
- BUG: Fixed unicode file names on Windows

## 0.2.0 (April 30, 2016)

- ENH: Windows support
- BUG: Fixes for 32-bit Apple systems

## 0.1.0 (March 29, 2016)

First Feather release
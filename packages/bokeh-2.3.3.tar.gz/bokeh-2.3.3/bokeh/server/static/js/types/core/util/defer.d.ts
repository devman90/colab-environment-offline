export declare function defer(): Promise<void>;
//# sourceMappingURL=defer.d.ts.map
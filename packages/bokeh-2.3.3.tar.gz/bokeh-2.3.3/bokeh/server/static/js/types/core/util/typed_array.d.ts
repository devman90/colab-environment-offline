import { TypedArray } from "../types";
export declare function concat<T extends TypedArray>(array0: T, ...arrays: T[]): T;
//# sourceMappingURL=typed_array.d.ts.map
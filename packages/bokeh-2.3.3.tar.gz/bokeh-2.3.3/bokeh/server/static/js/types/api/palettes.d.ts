export declare const YlGn3: number[];
export declare const YlGn4: number[];
export declare const YlGn5: number[];
export declare const YlGn6: number[];
export declare const YlGn7: number[];
export declare const YlGn8: number[];
export declare const YlGn9: number[];
export declare const YlGnBu3: number[];
export declare const YlGnBu4: number[];
export declare const YlGnBu5: number[];
export declare const YlGnBu6: number[];
export declare const YlGnBu7: number[];
export declare const YlGnBu8: number[];
export declare const YlGnBu9: number[];
export declare const GnBu3: number[];
export declare const GnBu4: number[];
export declare const GnBu5: number[];
export declare const GnBu6: number[];
export declare const GnBu7: number[];
export declare const GnBu8: number[];
export declare const GnBu9: number[];
export declare const BuGn3: number[];
export declare const BuGn4: number[];
export declare const BuGn5: number[];
export declare const BuGn6: number[];
export declare const BuGn7: number[];
export declare const BuGn8: number[];
export declare const BuGn9: number[];
export declare const PuBuGn3: number[];
export declare const PuBuGn4: number[];
export declare const PuBuGn5: number[];
export declare const PuBuGn6: number[];
export declare const PuBuGn7: number[];
export declare const PuBuGn8: number[];
export declare const PuBuGn9: number[];
export declare const PuBu3: number[];
export declare const PuBu4: number[];
export declare const PuBu5: number[];
export declare const PuBu6: number[];
export declare const PuBu7: number[];
export declare const PuBu8: number[];
export declare const PuBu9: number[];
export declare const BuPu3: number[];
export declare const BuPu4: number[];
export declare const BuPu5: number[];
export declare const BuPu6: number[];
export declare const BuPu7: number[];
export declare const BuPu8: number[];
export declare const BuPu9: number[];
export declare const RdPu3: number[];
export declare const RdPu4: number[];
export declare const RdPu5: number[];
export declare const RdPu6: number[];
export declare const RdPu7: number[];
export declare const RdPu8: number[];
export declare const RdPu9: number[];
export declare const PuRd3: number[];
export declare const PuRd4: number[];
export declare const PuRd5: number[];
export declare const PuRd6: number[];
export declare const PuRd7: number[];
export declare const PuRd8: number[];
export declare const PuRd9: number[];
export declare const OrRd3: number[];
export declare const OrRd4: number[];
export declare const OrRd5: number[];
export declare const OrRd6: number[];
export declare const OrRd7: number[];
export declare const OrRd8: number[];
export declare const OrRd9: number[];
export declare const YlOrRd3: number[];
export declare const YlOrRd4: number[];
export declare const YlOrRd5: number[];
export declare const YlOrRd6: number[];
export declare const YlOrRd7: number[];
export declare const YlOrRd8: number[];
export declare const YlOrRd9: number[];
export declare const YlOrBr3: number[];
export declare const YlOrBr4: number[];
export declare const YlOrBr5: number[];
export declare const YlOrBr6: number[];
export declare const YlOrBr7: number[];
export declare const YlOrBr8: number[];
export declare const YlOrBr9: number[];
export declare const Purples3: number[];
export declare const Purples4: number[];
export declare const Purples5: number[];
export declare const Purples6: number[];
export declare const Purples7: number[];
export declare const Purples8: number[];
export declare const Purples9: number[];
export declare const Blues3: number[];
export declare const Blues4: number[];
export declare const Blues5: number[];
export declare const Blues6: number[];
export declare const Blues7: number[];
export declare const Blues8: number[];
export declare const Blues9: number[];
export declare const Greens3: number[];
export declare const Greens4: number[];
export declare const Greens5: number[];
export declare const Greens6: number[];
export declare const Greens7: number[];
export declare const Greens8: number[];
export declare const Greens9: number[];
export declare const Oranges3: number[];
export declare const Oranges4: number[];
export declare const Oranges5: number[];
export declare const Oranges6: number[];
export declare const Oranges7: number[];
export declare const Oranges8: number[];
export declare const Oranges9: number[];
export declare const Reds3: number[];
export declare const Reds4: number[];
export declare const Reds5: number[];
export declare const Reds6: number[];
export declare const Reds7: number[];
export declare const Reds8: number[];
export declare const Reds9: number[];
export declare const Greys3: number[];
export declare const Greys4: number[];
export declare const Greys5: number[];
export declare const Greys6: number[];
export declare const Greys7: number[];
export declare const Greys8: number[];
export declare const Greys9: number[];
export declare const Greys10: number[];
export declare const Greys11: number[];
export declare const Greys256: number[];
export declare const PuOr3: number[];
export declare const PuOr4: number[];
export declare const PuOr5: number[];
export declare const PuOr6: number[];
export declare const PuOr7: number[];
export declare const PuOr8: number[];
export declare const PuOr9: number[];
export declare const PuOr10: number[];
export declare const PuOr11: number[];
export declare const BrBG3: number[];
export declare const BrBG4: number[];
export declare const BrBG5: number[];
export declare const BrBG6: number[];
export declare const BrBG7: number[];
export declare const BrBG8: number[];
export declare const BrBG9: number[];
export declare const BrBG10: number[];
export declare const BrBG11: number[];
export declare const PRGn3: number[];
export declare const PRGn4: number[];
export declare const PRGn5: number[];
export declare const PRGn6: number[];
export declare const PRGn7: number[];
export declare const PRGn8: number[];
export declare const PRGn9: number[];
export declare const PRGn10: number[];
export declare const PRGn11: number[];
export declare const PiYG3: number[];
export declare const PiYG4: number[];
export declare const PiYG5: number[];
export declare const PiYG6: number[];
export declare const PiYG7: number[];
export declare const PiYG8: number[];
export declare const PiYG9: number[];
export declare const PiYG10: number[];
export declare const PiYG11: number[];
export declare const RdBu3: number[];
export declare const RdBu4: number[];
export declare const RdBu5: number[];
export declare const RdBu6: number[];
export declare const RdBu7: number[];
export declare const RdBu8: number[];
export declare const RdBu9: number[];
export declare const RdBu10: number[];
export declare const RdBu11: number[];
export declare const RdGy3: number[];
export declare const RdGy4: number[];
export declare const RdGy5: number[];
export declare const RdGy6: number[];
export declare const RdGy7: number[];
export declare const RdGy8: number[];
export declare const RdGy9: number[];
export declare const RdGy10: number[];
export declare const RdGy11: number[];
export declare const RdYlBu3: number[];
export declare const RdYlBu4: number[];
export declare const RdYlBu5: number[];
export declare const RdYlBu6: number[];
export declare const RdYlBu7: number[];
export declare const RdYlBu8: number[];
export declare const RdYlBu9: number[];
export declare const RdYlBu10: number[];
export declare const RdYlBu11: number[];
export declare const Spectral3: number[];
export declare const Spectral4: number[];
export declare const Spectral5: number[];
export declare const Spectral6: number[];
export declare const Spectral7: number[];
export declare const Spectral8: number[];
export declare const Spectral9: number[];
export declare const Spectral10: number[];
export declare const Spectral11: number[];
export declare const RdYlGn3: number[];
export declare const RdYlGn4: number[];
export declare const RdYlGn5: number[];
export declare const RdYlGn6: number[];
export declare const RdYlGn7: number[];
export declare const RdYlGn8: number[];
export declare const RdYlGn9: number[];
export declare const RdYlGn10: number[];
export declare const RdYlGn11: number[];
export declare const Inferno3: number[];
export declare const Inferno4: number[];
export declare const Inferno5: number[];
export declare const Inferno6: number[];
export declare const Inferno7: number[];
export declare const Inferno8: number[];
export declare const Inferno9: number[];
export declare const Inferno10: number[];
export declare const Inferno11: number[];
export declare const Inferno256: number[];
export declare const Magma3: number[];
export declare const Magma4: number[];
export declare const Magma5: number[];
export declare const Magma6: number[];
export declare const Magma7: number[];
export declare const Magma8: number[];
export declare const Magma9: number[];
export declare const Magma10: number[];
export declare const Magma11: number[];
export declare const Magma256: number[];
export declare const Plasma3: number[];
export declare const Plasma4: number[];
export declare const Plasma5: number[];
export declare const Plasma6: number[];
export declare const Plasma7: number[];
export declare const Plasma8: number[];
export declare const Plasma9: number[];
export declare const Plasma10: number[];
export declare const Plasma11: number[];
export declare const Plasma256: number[];
export declare const Viridis3: number[];
export declare const Viridis4: number[];
export declare const Viridis5: number[];
export declare const Viridis6: number[];
export declare const Viridis7: number[];
export declare const Viridis8: number[];
export declare const Viridis9: number[];
export declare const Viridis10: number[];
export declare const Viridis11: number[];
export declare const Viridis256: number[];
export declare const Cividis3: number[];
export declare const Cividis4: number[];
export declare const Cividis5: number[];
export declare const Cividis6: number[];
export declare const Cividis7: number[];
export declare const Cividis8: number[];
export declare const Cividis9: number[];
export declare const Cividis10: number[];
export declare const Cividis11: number[];
export declare const Cividis256: number[];
export declare const Turbo3: number[];
export declare const Turbo4: number[];
export declare const Turbo5: number[];
export declare const Turbo6: number[];
export declare const Turbo7: number[];
export declare const Turbo8: number[];
export declare const Turbo9: number[];
export declare const Turbo10: number[];
export declare const Turbo11: number[];
export declare const Turbo256: number[];
export declare const Accent3: number[];
export declare const Accent4: number[];
export declare const Accent5: number[];
export declare const Accent6: number[];
export declare const Accent7: number[];
export declare const Accent8: number[];
export declare const Dark2_3: number[];
export declare const Dark2_4: number[];
export declare const Dark2_5: number[];
export declare const Dark2_6: number[];
export declare const Dark2_7: number[];
export declare const Dark2_8: number[];
export declare const Paired3: number[];
export declare const Paired4: number[];
export declare const Paired5: number[];
export declare const Paired6: number[];
export declare const Paired7: number[];
export declare const Paired8: number[];
export declare const Paired9: number[];
export declare const Paired10: number[];
export declare const Paired11: number[];
export declare const Paired12: number[];
export declare const Pastel1_3: number[];
export declare const Pastel1_4: number[];
export declare const Pastel1_5: number[];
export declare const Pastel1_6: number[];
export declare const Pastel1_7: number[];
export declare const Pastel1_8: number[];
export declare const Pastel1_9: number[];
export declare const Pastel2_3: number[];
export declare const Pastel2_4: number[];
export declare const Pastel2_5: number[];
export declare const Pastel2_6: number[];
export declare const Pastel2_7: number[];
export declare const Pastel2_8: number[];
export declare const Set1_3: number[];
export declare const Set1_4: number[];
export declare const Set1_5: number[];
export declare const Set1_6: number[];
export declare const Set1_7: number[];
export declare const Set1_8: number[];
export declare const Set1_9: number[];
export declare const Set2_3: number[];
export declare const Set2_4: number[];
export declare const Set2_5: number[];
export declare const Set2_6: number[];
export declare const Set2_7: number[];
export declare const Set2_8: number[];
export declare const Set3_3: number[];
export declare const Set3_4: number[];
export declare const Set3_5: number[];
export declare const Set3_6: number[];
export declare const Set3_7: number[];
export declare const Set3_8: number[];
export declare const Set3_9: number[];
export declare const Set3_10: number[];
export declare const Set3_11: number[];
export declare const Set3_12: number[];
export declare const Category10_3: number[];
export declare const Category10_4: number[];
export declare const Category10_5: number[];
export declare const Category10_6: number[];
export declare const Category10_7: number[];
export declare const Category10_8: number[];
export declare const Category10_9: number[];
export declare const Category10_10: number[];
export declare const Category20_3: number[];
export declare const Category20_4: number[];
export declare const Category20_5: number[];
export declare const Category20_6: number[];
export declare const Category20_7: number[];
export declare const Category20_8: number[];
export declare const Category20_9: number[];
export declare const Category20_10: number[];
export declare const Category20_11: number[];
export declare const Category20_12: number[];
export declare const Category20_13: number[];
export declare const Category20_14: number[];
export declare const Category20_15: number[];
export declare const Category20_16: number[];
export declare const Category20_17: number[];
export declare const Category20_18: number[];
export declare const Category20_19: number[];
export declare const Category20_20: number[];
export declare const Category20b_3: number[];
export declare const Category20b_4: number[];
export declare const Category20b_5: number[];
export declare const Category20b_6: number[];
export declare const Category20b_7: number[];
export declare const Category20b_8: number[];
export declare const Category20b_9: number[];
export declare const Category20b_10: number[];
export declare const Category20b_11: number[];
export declare const Category20b_12: number[];
export declare const Category20b_13: number[];
export declare const Category20b_14: number[];
export declare const Category20b_15: number[];
export declare const Category20b_16: number[];
export declare const Category20b_17: number[];
export declare const Category20b_18: number[];
export declare const Category20b_19: number[];
export declare const Category20b_20: number[];
export declare const Category20c_3: number[];
export declare const Category20c_4: number[];
export declare const Category20c_5: number[];
export declare const Category20c_6: number[];
export declare const Category20c_7: number[];
export declare const Category20c_8: number[];
export declare const Category20c_9: number[];
export declare const Category20c_10: number[];
export declare const Category20c_11: number[];
export declare const Category20c_12: number[];
export declare const Category20c_13: number[];
export declare const Category20c_14: number[];
export declare const Category20c_15: number[];
export declare const Category20c_16: number[];
export declare const Category20c_17: number[];
export declare const Category20c_18: number[];
export declare const Category20c_19: number[];
export declare const Category20c_20: number[];
export declare const Colorblind3: number[];
export declare const Colorblind4: number[];
export declare const Colorblind5: number[];
export declare const Colorblind6: number[];
export declare const Colorblind7: number[];
export declare const Colorblind8: number[];
export declare type YlGn = "YlGn3" | "YlGn4" | "YlGn5" | "YlGn6" | "YlGn7" | "YlGn8" | "YlGn9";
export declare type YlGnBu = "YlGnBu3" | "YlGnBu4" | "YlGnBu5" | "YlGnBu6" | "YlGnBu7" | "YlGnBu8" | "YlGnBu9";
export declare type GnBu = "GnBu3" | "GnBu4" | "GnBu5" | "GnBu6" | "GnBu7" | "GnBu8" | "GnBu9";
export declare type BuGn = "BuGn3" | "BuGn4" | "BuGn5" | "BuGn6" | "BuGn7" | "BuGn8" | "BuGn9";
export declare type PuBuGn = "PuBuGn3" | "PuBuGn4" | "PuBuGn5" | "PuBuGn6" | "PuBuGn7" | "PuBuGn8" | "PuBuGn9";
export declare type PuBu = "PuBu3" | "PuBu4" | "PuBu5" | "PuBu6" | "PuBu7" | "PuBu8" | "PuBu9";
export declare type BuPu = "BuPu3" | "BuPu4" | "BuPu5" | "BuPu6" | "BuPu7" | "BuPu8" | "BuPu9";
export declare type RdPu = "RdPu3" | "RdPu4" | "RdPu5" | "RdPu6" | "RdPu7" | "RdPu8" | "RdPu9";
export declare type PuRd = "PuRd3" | "PuRd4" | "PuRd5" | "PuRd6" | "PuRd7" | "PuRd8" | "PuRd9";
export declare type OrRd = "OrRd3" | "OrRd4" | "OrRd5" | "OrRd6" | "OrRd7" | "OrRd8" | "OrRd9";
export declare type YlOrRd = "YlOrRd3" | "YlOrRd4" | "YlOrRd5" | "YlOrRd6" | "YlOrRd7" | "YlOrRd8" | "YlOrRd9";
export declare type YlOrBr = "YlOrBr3" | "YlOrBr4" | "YlOrBr5" | "YlOrBr6" | "YlOrBr7" | "YlOrBr8" | "YlOrBr9";
export declare type Purples = "Purples3" | "Purples4" | "Purples5" | "Purples6" | "Purples7" | "Purples8" | "Purples9";
export declare type Blues = "Blues3" | "Blues4" | "Blues5" | "Blues6" | "Blues7" | "Blues8" | "Blues9";
export declare type Greens = "Greens3" | "Greens4" | "Greens5" | "Greens6" | "Greens7" | "Greens8" | "Greens9";
export declare type Oranges = "Oranges3" | "Oranges4" | "Oranges5" | "Oranges6" | "Oranges7" | "Oranges8" | "Oranges9";
export declare type Reds = "Reds3" | "Reds4" | "Reds5" | "Reds6" | "Reds7" | "Reds8" | "Reds9";
export declare type Greys = "Greys3" | "Greys4" | "Greys5" | "Greys6" | "Greys7" | "Greys8" | "Greys9";
export declare type PuOr = "PuOr3" | "PuOr4" | "PuOr5" | "PuOr6" | "PuOr7" | "PuOr8" | "PuOr9" | "PuOr10" | "PuOr11";
export declare type BrBG = "BrBG3" | "BrBG4" | "BrBG5" | "BrBG6" | "BrBG7" | "BrBG8" | "BrBG9" | "BrBG10" | "BrBG11";
export declare type PRGn = "PRGn3" | "PRGn4" | "PRGn5" | "PRGn6" | "PRGn7" | "PRGn8" | "PRGn9" | "PRGn10" | "PRGn11";
export declare type PiYG = "PiYG3" | "PiYG4" | "PiYG5" | "PiYG6" | "PiYG7" | "PiYG8" | "PiYG9" | "PiYG10" | "PiYG11";
export declare type RdBu = "RdBu3" | "RdBu4" | "RdBu5" | "RdBu6" | "RdBu7" | "RdBu8" | "RdBu9" | "RdBu10" | "RdBu11";
export declare type RdGy = "RdGy3" | "RdGy4" | "RdGy5" | "RdGy6" | "RdGy7" | "RdGy8" | "RdGy9" | "RdGy10" | "RdGy11";
export declare type RdYlBu = "RdYlBu3" | "RdYlBu4" | "RdYlBu5" | "RdYlBu6" | "RdYlBu7" | "RdYlBu8" | "RdYlBu9" | "RdYlBu10" | "RdYlBu11";
export declare type Spectral = "Spectral3" | "Spectral4" | "Spectral5" | "Spectral6" | "Spectral7" | "Spectral8" | "Spectral9" | "Spectral10" | "Spectral11";
export declare type RdYlGn = "RdYlGn3" | "RdYlGn4" | "RdYlGn5" | "RdYlGn6" | "RdYlGn7" | "RdYlGn8" | "RdYlGn9" | "RdYlGn10" | "RdYlGn11";
export declare type Accent = "Accent3" | "Accent4" | "Accent5" | "Accent6" | "Accent7" | "Accent8";
export declare type Dark2 = "Dark2_3" | "Dark2_4" | "Dark2_5" | "Dark2_6" | "Dark2_7" | "Dark2_8";
export declare type Paired = "Paired3" | "Paired4" | "Paired5" | "Paired6" | "Paired7" | "Paired8" | "Paired9" | "Paired10" | "Paired11" | "Paired12";
export declare type Pastel1 = "Pastel1_3" | "Pastel1_4" | "Pastel1_5" | "Pastel1_6" | "Pastel1_7" | "Pastel1_8" | "Pastel1_9";
export declare type Pastel2 = "Pastel2_3" | "Pastel2_4" | "Pastel2_5" | "Pastel2_6" | "Pastel2_7" | "Pastel2_8";
export declare type Set1 = "Set1_3" | "Set1_4" | "Set1_5" | "Set1_6" | "Set1_7" | "Set1_8" | "Set1_9";
export declare type Set2 = "Set2_3" | "Set2_4" | "Set2_5" | "Set2_6" | "Set2_7" | "Set2_8";
export declare type Set3 = "Set3_3" | "Set3_4" | "Set3_5" | "Set3_6" | "Set3_7" | "Set3_8" | "Set3_9" | "Set3_10" | "Set3_11" | "Set3_12";
export declare type Inferno = "Inferno3" | "Inferno4" | "Inferno5" | "Inferno6" | "Inferno7" | "Inferno8" | "Inferno9" | "Inferno10" | "Inferno11" | "Inferno256";
export declare type Magma = "Magma3" | "Magma4" | "Magma5" | "Magma6" | "Magma7" | "Magma8" | "Magma9" | "Magma10" | "Magma11" | "Magma256";
export declare type Plasma = "Plasma3" | "Plasma4" | "Plasma5" | "Plasma6" | "Plasma7" | "Plasma8" | "Plasma9" | "Plasma10" | "Plasma11" | "Plasma256";
export declare type Viridis = "Viridis3" | "Viridis4" | "Viridis5" | "Viridis6" | "Viridis7" | "Viridis8" | "Viridis9" | "Viridis10" | "Viridis11" | "Viridis256";
export declare type Category10 = "Category10_3" | "Category10_4" | "Category10_5" | "Category10_6" | "Category10_7" | "Category10_8" | "Category10_9" | "Category10_10";
export declare type Category20 = "Category20_3" | "Category20_4" | "Category20_5" | "Category20_6" | "Category20_7" | "Category20_8" | "Category20_9" | "Category20_10" | "Category20_11" | "Category20_12" | "Category20_13" | "Category20_14" | "Category20_15" | "Category20_16" | "Category20_17" | "Category20_18" | "Category20_19" | "Category20_20";
export declare type Category20b = "Category20b_3" | "Category20b_4" | "Category20b_5" | "Category20b_6" | "Category20b_7" | "Category20b_8" | "Category20b_9" | "Category20b_10" | "Category20b_11" | "Category20b_12" | "Category20b_13" | "Category20b_14" | "Category20b_15" | "Category20b_16" | "Category20b_17" | "Category20b_18" | "Category20b_19" | "Category20b_20";
export declare type Category20c = "Category20c_3" | "Category20c_4" | "Category20c_5" | "Category20c_6" | "Category20c_7" | "Category20c_8" | "Category20c_9" | "Category20c_10" | "Category20c_11" | "Category20c_12" | "Category20c_13" | "Category20c_14" | "Category20c_15" | "Category20c_16" | "Category20c_17" | "Category20c_18" | "Category20c_19" | "Category20c_20";
export declare type Colorblind = "Colorblind3" | "Colorblind4" | "Colorblind5" | "Colorblind6" | "Colorblind7" | "Colorblind8";
export declare type Palette = YlGn | YlGnBu | GnBu | BuGn | PuBuGn | PuBu | BuPu | RdPu | PuRd | OrRd | YlOrRd | YlOrBr | Purples | Blues | Greens | Oranges | Reds | Greys | PuOr | BrBG | PRGn | PiYG | RdBu | RdGy | RdYlBu | Spectral | RdYlGn | Accent | Dark2 | Paired | Pastel1 | Pastel2 | Set1 | Set2 | Set3 | Inferno | Magma | Plasma | Viridis | Category10 | Category20 | Category20b | Category20c | Colorblind;
export declare const YlGn: {
    YlGn3: number[];
    YlGn4: number[];
    YlGn5: number[];
    YlGn6: number[];
    YlGn7: number[];
    YlGn8: number[];
    YlGn9: number[];
};
export declare const YlGnBu: {
    YlGnBu3: number[];
    YlGnBu4: number[];
    YlGnBu5: number[];
    YlGnBu6: number[];
    YlGnBu7: number[];
    YlGnBu8: number[];
    YlGnBu9: number[];
};
export declare const GnBu: {
    GnBu3: number[];
    GnBu4: number[];
    GnBu5: number[];
    GnBu6: number[];
    GnBu7: number[];
    GnBu8: number[];
    GnBu9: number[];
};
export declare const BuGn: {
    BuGn3: number[];
    BuGn4: number[];
    BuGn5: number[];
    BuGn6: number[];
    BuGn7: number[];
    BuGn8: number[];
    BuGn9: number[];
};
export declare const PuBuGn: {
    PuBuGn3: number[];
    PuBuGn4: number[];
    PuBuGn5: number[];
    PuBuGn6: number[];
    PuBuGn7: number[];
    PuBuGn8: number[];
    PuBuGn9: number[];
};
export declare const PuBu: {
    PuBu3: number[];
    PuBu4: number[];
    PuBu5: number[];
    PuBu6: number[];
    PuBu7: number[];
    PuBu8: number[];
    PuBu9: number[];
};
export declare const BuPu: {
    BuPu3: number[];
    BuPu4: number[];
    BuPu5: number[];
    BuPu6: number[];
    BuPu7: number[];
    BuPu8: number[];
    BuPu9: number[];
};
export declare const RdPu: {
    RdPu3: number[];
    RdPu4: number[];
    RdPu5: number[];
    RdPu6: number[];
    RdPu7: number[];
    RdPu8: number[];
    RdPu9: number[];
};
export declare const PuRd: {
    PuRd3: number[];
    PuRd4: number[];
    PuRd5: number[];
    PuRd6: number[];
    PuRd7: number[];
    PuRd8: number[];
    PuRd9: number[];
};
export declare const OrRd: {
    OrRd3: number[];
    OrRd4: number[];
    OrRd5: number[];
    OrRd6: number[];
    OrRd7: number[];
    OrRd8: number[];
    OrRd9: number[];
};
export declare const YlOrRd: {
    YlOrRd3: number[];
    YlOrRd4: number[];
    YlOrRd5: number[];
    YlOrRd6: number[];
    YlOrRd7: number[];
    YlOrRd8: number[];
    YlOrRd9: number[];
};
export declare const YlOrBr: {
    YlOrBr3: number[];
    YlOrBr4: number[];
    YlOrBr5: number[];
    YlOrBr6: number[];
    YlOrBr7: number[];
    YlOrBr8: number[];
    YlOrBr9: number[];
};
export declare const Purples: {
    Purples3: number[];
    Purples4: number[];
    Purples5: number[];
    Purples6: number[];
    Purples7: number[];
    Purples8: number[];
    Purples9: number[];
};
export declare const Blues: {
    Blues3: number[];
    Blues4: number[];
    Blues5: number[];
    Blues6: number[];
    Blues7: number[];
    Blues8: number[];
    Blues9: number[];
};
export declare const Greens: {
    Greens3: number[];
    Greens4: number[];
    Greens5: number[];
    Greens6: number[];
    Greens7: number[];
    Greens8: number[];
    Greens9: number[];
};
export declare const Oranges: {
    Oranges3: number[];
    Oranges4: number[];
    Oranges5: number[];
    Oranges6: number[];
    Oranges7: number[];
    Oranges8: number[];
    Oranges9: number[];
};
export declare const Reds: {
    Reds3: number[];
    Reds4: number[];
    Reds5: number[];
    Reds6: number[];
    Reds7: number[];
    Reds8: number[];
    Reds9: number[];
};
export declare const Greys: {
    Greys3: number[];
    Greys4: number[];
    Greys5: number[];
    Greys6: number[];
    Greys7: number[];
    Greys8: number[];
    Greys9: number[];
    Greys10: number[];
    Greys11: number[];
    Greys256: number[];
};
export declare const PuOr: {
    PuOr3: number[];
    PuOr4: number[];
    PuOr5: number[];
    PuOr6: number[];
    PuOr7: number[];
    PuOr8: number[];
    PuOr9: number[];
    PuOr10: number[];
    PuOr11: number[];
};
export declare const BrBG: {
    BrBG3: number[];
    BrBG4: number[];
    BrBG5: number[];
    BrBG6: number[];
    BrBG7: number[];
    BrBG8: number[];
    BrBG9: number[];
    BrBG10: number[];
    BrBG11: number[];
};
export declare const PRGn: {
    PRGn3: number[];
    PRGn4: number[];
    PRGn5: number[];
    PRGn6: number[];
    PRGn7: number[];
    PRGn8: number[];
    PRGn9: number[];
    PRGn10: number[];
    PRGn11: number[];
};
export declare const PiYG: {
    PiYG3: number[];
    PiYG4: number[];
    PiYG5: number[];
    PiYG6: number[];
    PiYG7: number[];
    PiYG8: number[];
    PiYG9: number[];
    PiYG10: number[];
    PiYG11: number[];
};
export declare const RdBu: {
    RdBu3: number[];
    RdBu4: number[];
    RdBu5: number[];
    RdBu6: number[];
    RdBu7: number[];
    RdBu8: number[];
    RdBu9: number[];
    RdBu10: number[];
    RdBu11: number[];
};
export declare const RdGy: {
    RdGy3: number[];
    RdGy4: number[];
    RdGy5: number[];
    RdGy6: number[];
    RdGy7: number[];
    RdGy8: number[];
    RdGy9: number[];
    RdGy10: number[];
    RdGy11: number[];
};
export declare const RdYlBu: {
    RdYlBu3: number[];
    RdYlBu4: number[];
    RdYlBu5: number[];
    RdYlBu6: number[];
    RdYlBu7: number[];
    RdYlBu8: number[];
    RdYlBu9: number[];
    RdYlBu10: number[];
    RdYlBu11: number[];
};
export declare const Spectral: {
    Spectral3: number[];
    Spectral4: number[];
    Spectral5: number[];
    Spectral6: number[];
    Spectral7: number[];
    Spectral8: number[];
    Spectral9: number[];
    Spectral10: number[];
    Spectral11: number[];
};
export declare const RdYlGn: {
    RdYlGn3: number[];
    RdYlGn4: number[];
    RdYlGn5: number[];
    RdYlGn6: number[];
    RdYlGn7: number[];
    RdYlGn8: number[];
    RdYlGn9: number[];
    RdYlGn10: number[];
    RdYlGn11: number[];
};
export declare const Inferno: {
    Inferno3: number[];
    Inferno4: number[];
    Inferno5: number[];
    Inferno6: number[];
    Inferno7: number[];
    Inferno8: number[];
    Inferno9: number[];
    Inferno10: number[];
    Inferno11: number[];
    Inferno256: number[];
};
export declare const Magma: {
    Magma3: number[];
    Magma4: number[];
    Magma5: number[];
    Magma6: number[];
    Magma7: number[];
    Magma8: number[];
    Magma9: number[];
    Magma10: number[];
    Magma11: number[];
    Magma256: number[];
};
export declare const Plasma: {
    Plasma3: number[];
    Plasma4: number[];
    Plasma5: number[];
    Plasma6: number[];
    Plasma7: number[];
    Plasma8: number[];
    Plasma9: number[];
    Plasma10: number[];
    Plasma11: number[];
    Plasma256: number[];
};
export declare const Viridis: {
    Viridis3: number[];
    Viridis4: number[];
    Viridis5: number[];
    Viridis6: number[];
    Viridis7: number[];
    Viridis8: number[];
    Viridis9: number[];
    Viridis10: number[];
    Viridis11: number[];
    Viridis256: number[];
};
export declare const Accent: {
    Accent3: number[];
    Accent4: number[];
    Accent5: number[];
    Accent6: number[];
    Accent7: number[];
    Accent8: number[];
};
export declare const Dark2: {
    Dark2_3: number[];
    Dark2_4: number[];
    Dark2_5: number[];
    Dark2_6: number[];
    Dark2_7: number[];
    Dark2_8: number[];
};
export declare const Paired: {
    Paired3: number[];
    Paired4: number[];
    Paired5: number[];
    Paired6: number[];
    Paired7: number[];
    Paired8: number[];
    Paired9: number[];
    Paired10: number[];
    Paired11: number[];
    Paired12: number[];
};
export declare const Pastel1: {
    Pastel1_3: number[];
    Pastel1_4: number[];
    Pastel1_5: number[];
    Pastel1_6: number[];
    Pastel1_7: number[];
    Pastel1_8: number[];
    Pastel1_9: number[];
};
export declare const Pastel2: {
    Pastel2_3: number[];
    Pastel2_4: number[];
    Pastel2_5: number[];
    Pastel2_6: number[];
    Pastel2_7: number[];
    Pastel2_8: number[];
};
export declare const Set1: {
    Set1_3: number[];
    Set1_4: number[];
    Set1_5: number[];
    Set1_6: number[];
    Set1_7: number[];
    Set1_8: number[];
    Set1_9: number[];
};
export declare const Set2: {
    Set2_3: number[];
    Set2_4: number[];
    Set2_5: number[];
    Set2_6: number[];
    Set2_7: number[];
    Set2_8: number[];
};
export declare const Set3: {
    Set3_3: number[];
    Set3_4: number[];
    Set3_5: number[];
    Set3_6: number[];
    Set3_7: number[];
    Set3_8: number[];
    Set3_9: number[];
    Set3_10: number[];
    Set3_11: number[];
    Set3_12: number[];
};
export declare const Category10: {
    Category10_3: number[];
    Category10_4: number[];
    Category10_5: number[];
    Category10_6: number[];
    Category10_7: number[];
    Category10_8: number[];
    Category10_9: number[];
    Category10_10: number[];
};
export declare const Category20: {
    Category20_3: number[];
    Category20_4: number[];
    Category20_5: number[];
    Category20_6: number[];
    Category20_7: number[];
    Category20_8: number[];
    Category20_9: number[];
    Category20_10: number[];
    Category20_11: number[];
    Category20_12: number[];
    Category20_13: number[];
    Category20_14: number[];
    Category20_15: number[];
    Category20_16: number[];
    Category20_17: number[];
    Category20_18: number[];
    Category20_19: number[];
    Category20_20: number[];
};
export declare const Category20b: {
    Category20b_3: number[];
    Category20b_4: number[];
    Category20b_5: number[];
    Category20b_6: number[];
    Category20b_7: number[];
    Category20b_8: number[];
    Category20b_9: number[];
    Category20b_10: number[];
    Category20b_11: number[];
    Category20b_12: number[];
    Category20b_13: number[];
    Category20b_14: number[];
    Category20b_15: number[];
    Category20b_16: number[];
    Category20b_17: number[];
    Category20b_18: number[];
    Category20b_19: number[];
    Category20b_20: number[];
};
export declare const Category20c: {
    Category20c_3: number[];
    Category20c_4: number[];
    Category20c_5: number[];
    Category20c_6: number[];
    Category20c_7: number[];
    Category20c_8: number[];
    Category20c_9: number[];
    Category20c_10: number[];
    Category20c_11: number[];
    Category20c_12: number[];
    Category20c_13: number[];
    Category20c_14: number[];
    Category20c_15: number[];
    Category20c_16: number[];
    Category20c_17: number[];
    Category20c_18: number[];
    Category20c_19: number[];
    Category20c_20: number[];
};
export declare const Colorblind: {
    Colorblind3: number[];
    Colorblind4: number[];
    Colorblind5: number[];
    Colorblind6: number[];
    Colorblind7: number[];
    Colorblind8: number[];
};
export declare function linear_palette<T>(palette: T[], n: number): T[];
export declare function magma(n: number): number[];
export declare function inferno(n: number): number[];
export declare function plasma(n: number): number[];
export declare function viridis(n: number): number[];
export declare function cividis(n: number): number[];
export declare function turbo(n: number): number[];
export declare function grey(n: number): number[];
/****************************************************************************
 * License regarding the Viridis, Magma, Plasma and Inferno colormaps
 * New matplotlib colormaps by Nathaniel J. Smith, Stefan van der Walt,
 * and (in the case of viridis) Eric Firing.
 *
 * The Viridis, Magma, Plasma, and Inferno color maps are released under the
 * CC0 license / public domain dedication. We would appreciate credit if you
 * use or redistribute these colormaps, but do not impose any legal
 * restrictions.
 *
 * To the extent possible under law, the persons who associated CC0 with
 * mpl-colormaps have waived all copyright and related or neighboring rights
 * to mpl-colormaps.
 *
 * You should have received a copy of the CC0 legalcode along with this
 * work.  If not, see <http://creativecommons.org/publicdomain/zero/1.0/>.
 ****************************************************************************
 * This product includes color specifications and designs developed by
 * Cynthia Brewer (http://colorbrewer2.org/).  The Brewer colormaps are
 * licensed under the Apache v2 license. You may obtain a copy of the
 * License at http://www.apache.org/licenses/LICENSE-2.0
 ****************************************************************************
 * License regarding the D3 color palettes (Category10, Category20,
 * Category20b, and Category 20c):
 *
 * Copyright 2010-2015 Mike Bostock
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * * Neither the name of the author nor the names of contributors may be used to
 *   endorse or promote products derived from this software without specific
 *   prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ****************************************************************************
 */
//# sourceMappingURL=palettes.d.ts.map
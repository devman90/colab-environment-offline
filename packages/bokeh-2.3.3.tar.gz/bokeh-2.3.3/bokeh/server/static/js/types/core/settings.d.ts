export declare class Settings {
    private _dev;
    private _wireframe;
    set dev(dev: boolean);
    get dev(): boolean;
    set wireframe(wireframe: boolean);
    get wireframe(): boolean;
}
export declare const settings: Settings;
//# sourceMappingURL=settings.d.ts.map
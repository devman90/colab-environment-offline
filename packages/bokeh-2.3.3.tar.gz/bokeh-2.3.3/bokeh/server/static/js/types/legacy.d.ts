import "./polyfill";
export * from "./main";
//# sourceMappingURL=legacy.d.ts.map
import { RenderItem } from "./json";
export declare const BOKEH_ROOT: string;
export declare function _resolve_element(item: RenderItem): HTMLElement;
export declare function _resolve_root_elements(item: RenderItem): HTMLElement[];
//# sourceMappingURL=dom.d.ts.map
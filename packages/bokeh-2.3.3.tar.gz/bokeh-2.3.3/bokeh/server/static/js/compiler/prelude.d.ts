export declare function comment(text: string): string;
export declare function prelude_esm(): string;
export declare function postlude_esm(): string;
export declare function plugin_prelude_esm(): string;
export declare function plugin_postlude_esm(): string;
export declare function prelude(): string;
export declare function postlude(): string;
export declare function plugin_postlude(): string;
export declare function plugin_prelude(options?: {
    version?: string;
}): string;
export declare function default_prelude(options?: {
    global?: string;
}): string;
//# sourceMappingURL=prelude.d.ts.map
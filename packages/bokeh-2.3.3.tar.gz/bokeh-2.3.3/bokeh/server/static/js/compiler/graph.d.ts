export declare type Graph<T> = Map<T, T[]>;
export declare function detect_cycles<T>(graph: Graph<T>): T[][];
//# sourceMappingURL=graph.d.ts.map
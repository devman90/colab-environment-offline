export declare function compile_styles(styles_dir: string, css_dir: string): Promise<boolean>;
export declare function wrap_css_modules(css_dir: string, js_dir: string, dts_dir: string): void;
//# sourceMappingURL=styles.d.ts.map
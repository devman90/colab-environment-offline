from theano.sandbox.linalg.ops import psd, spectral_radius_bound
from theano.tensor.nlinalg import (
    alloc_diag,
    det,
    diag,
    eig,
    eigh,
    extract_diag,
    matrix_inverse,
    trace,
)
from theano.tensor.slinalg import cholesky, eigvalsh, solve

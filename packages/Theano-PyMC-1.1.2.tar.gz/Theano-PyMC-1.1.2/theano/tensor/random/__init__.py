# Initialize `RandomVariable` optimizations
import theano.tensor.random.opt
import theano.tensor.random.utils

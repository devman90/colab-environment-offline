bottleneck.reduce module
============================

Module contents
---------------

.. automodule:: bottleneck.reduce
   :members:
   :undoc-members:
   :show-inheritance:

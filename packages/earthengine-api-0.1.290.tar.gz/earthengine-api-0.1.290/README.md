Visit the [Google Earth Engine Python installation page](https://developers.google.com/earth-engine/python_install)
for set up instructions.

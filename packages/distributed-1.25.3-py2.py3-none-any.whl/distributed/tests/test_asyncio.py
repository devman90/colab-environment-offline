import sys


if sys.version_info >= (3, 5):
    from distributed.tests.py3_test_asyncio import *  # noqa: F401, F403

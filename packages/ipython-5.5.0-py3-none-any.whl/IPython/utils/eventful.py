from __future__ import absolute_import

from warnings import warn

warn("IPython.utils.eventful has moved to traitlets.eventful")

from traitlets.eventful import *

moviepy\.video\.fx\.all\.mask\_or
=================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: mask_or
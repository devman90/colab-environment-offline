moviepy.video.fx.all.rotate
=============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: rotate
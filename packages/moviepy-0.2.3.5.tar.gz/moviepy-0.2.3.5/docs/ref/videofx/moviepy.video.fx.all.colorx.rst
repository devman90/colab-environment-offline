moviepy.video.fx.all.colorx
===========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: colorx
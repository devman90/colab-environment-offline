moviepy.video.fx.all.blackwhite
===============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: blackwhite
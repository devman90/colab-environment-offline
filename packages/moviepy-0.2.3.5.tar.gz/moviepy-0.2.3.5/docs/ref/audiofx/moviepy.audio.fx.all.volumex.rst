moviepy.audio.fx.all.volumex
============================

.. currentmodule:: moviepy.audio.fx.all

.. autofunction:: volumex